
def get_face_info():
    
    face_info = []
    try:
        skin_tone = input("What is your your skin tone? (fair, medium, or dark): ")
    except ValueError:
        print ("Invalid input.")
        #Does this do anything? How can I see if my input is correct in python?
    face_info.append(skin_tone)
    try:
        skin_undertone = input("What is your skin undertone? (cool, warm, or nuetral): ")
    except ValueError:
        print ("Invalid input.")
    face_info.append(skin_undertone)
    try:
        skin_type = input("What is your skin type? (dry, oily, or combination): ")
    except ValueError:
        print ("Invalid input.")
    face_info.append(skin_type)
    try:
        face_shape = input("What is your face shape? (oval, heart, square, diamond, long, or round): ")
    except ValueError:
        print ("Invalid input.")
    face_info.append(face_shape)
    try:
        eyebrow_shape = input("What is your eyebrow shape? (straight, arched, or super-arched): ")
    except ValueError:
        print ("Invalid input.")
    face_info.append(eyebrow_shape)
    try:
        #add deep set
        eye_shape = input("What is your eye shape? (far set, close set, prominent, hooded, monolid, downturned, upturned, round, almond): ")
    except ValueError:
        print ("Invalid input.")   
    face_info.append(eye_shape)
    try:
        eye_color = input("What is your eye color? (green, blue, hazel, brown, or gray): ")
    except ValueError:
        print ("Invalid input.")
    face_info.append(eye_color)
    try:
        nose_shape = input("What is your nose shape? (long, short, narrow, wide, hooknose): ")
    except ValueError:
        print ("Invalid input.")
    face_info.append(nose_shape)
    try:
        chin_and_jaw_shape = input("What does your jaw/chin structure look like? (wide jaw, no jaw, receding chin, or advancing chin): ")
    except ValueError:
        print ("Invalid input.")  
    face_info.append(chin_and_jaw_shape)
    try:
        lip_shape = input("What kind of lips do you have? (full lips, thin lower and full upper, thin upper and full lower, thin lips): ")
    except ValueError:
        print ("Invalid input.")
    face_info.append(lip_shape)
    return face_info

#use a list to allow you to choose more than one option or create different variables and options. Same for the eye shape.
# eye info function param = face_array[0], face_array[1].
#if invalid input say invalid input use an exception and for loop to see how many faces someone wants - how many times to use the code.

def color_family(skin_tone, skin_undertone):
    print (" ")
    print (" ")
    print ("When applying makeup, it is important to consider the color family best for you to stick to.")
    print ("This ensures that your makeup flatters your beauty and doesn't mess it up color wise.")
    print (" ")
    if skin_tone == "fair":
        print ("You have a beautiful, fair skin tone.")
        print ("To compliment your skin tone, you should use soft colors, such as:")
        print ("Light pinks, beiges, light blue, light green.")
        print ("Unless you are going for a bold look, you may want to avoid primarily using harsh colors, such as:")
        print ("Oranges, reds, dark browns.")
        print ("You can include them in your makeup look, but you don't want them to be the primary colors you work with.")
    if skin_tone == "medium":
        print ("You have a beautiful, neutral, medium skin tone.")
        print ("There are many colors that will compliment your skin tone, such as:")
        print ("Golds, pinks, beiges, honey-colors, peaches.")
        print ("Because your skin tone is in the middle, there are no colors that you should avoid.")
        print ("You are welcome to choose the colors you like the best.")
    if skin_tone == "dark":
        print ("You have a beautiful, deep, dark skin tone.")
        print ("The colors that will best suit you are deep colors, such as:")
        print ("chestnut, plum, muave, burgundy, dark brown.")
    print (" ")
    print ("You now know the general color families you should stick with for your overall makeup look.")
    print ("Keep this in mind when applying foundation, eye makeup, bronzer, contour, blush, and lip color.")
    print (" ")
    print ("For color to best compliment you, your skin undertone should be taken into account as well.")
    print ("This may narrow down your color family options just a bit.")
    if skin_undertone == "cool":
        print ("Your skin has a cool undertone.")
        print ("You may want to match your undertone by using cool colors, such as:")
        print ("Sky blues, cobalt, frosty purples, emerald greens, pale pinks, grays.")
    if skin_undertone == "warm":
        print ("Your skin has a warm undertone.")
        print ("You may want to match your undertone by using warm colors, such as:")
        print ("Bronzes, browns, golds.")
        print ("Cool colors may wash your face out, so be sure to avoid them.")
    if skin_undertone == "nuetral":
        print ("Your skin has a nuetral undertone.")
        print ("Yay! You can choose whatever colors you like, (just keep in mind your skin tone color compliments).")

def eye_makeup(eye, color, face_shape):
    
    print (" ")
    print ("When applying makeup, it is best to begin with the eyebrow and eye, so that any fallout from the application can be covered up with foundation.")
    print ("Eyebrows play a big part in corrective makeup, because they influence the eye appearance and face shape.")
    print ("Based on your face shape, there a different eye brow shapes that suit you.")
    if face_shape == "oval":
        print ("Your oval shaped face looks smashing with linear eyebrows.")
        print ("When lining the eyebrows, keep the arch small.")
        print ("Use an eyebrow brush to brush the eyebrows out, and blend the eyebrow fill so that it looks natural and not artificial.")
        print ("Please, you do NOT want artificial eyebrows, TRUST me.")
    if face_shape == "round":
        print ("Your round shaped face looks smashing with linear eyebrows.")
        print ("When lining the eyebrows, keep the arch small.")
        print ("Use an eyebrow brush to brush the eyebrows out, and blend the eyebrow fill so that it looks natural and not artificial.")
        print ("Please, you do NOT want artificial eyebrows, TRUST me.")
    if face_shape == "diamond":
        print ("Your diamond shaped face looks smashing with linear eyebrows.")
        print ("When lining the eyebrows, keep the arch small.")
        print ("Use an eyebrow brush to brush the eyebrows out, and blend the eyebrow fill so that it looks natural and not artificial.")
        print ("Please, you do NOT want artificial eyebrows, TRUST me.")
    if face_shape == "heart":
        print ("Your heart shaped face looks awesome with a balanced arched eyebrow.")
        print ("When lining the brow, try to create a nice arch, but not a dramatic one.")
        print ("Use an eyebrow brush to brush the eyebrows out, and blend the eyebrow fill so that it looks natural and not artificial.")
        print ("Please, you do NOT want artificial eyebrows, TRUST me.")
    if face_shape == "square":
        print ("Your square shaped face looks awesome with high arched brows.")
        print ("When lining the brow, create a dramatic arch.")
        print ("Use an eyebrow brush to brush the eyebrows out, and blend the eyebrow fill so that it looks natural and not artificial.")
        print ("Please, you do NOT want artificial eyebrows, TRUST me.")
    if face_shape == "long":
        print ("Your long face looks awesome with high arched brows.")
        print ("When lining the brow, create a dramatic arch.")
        print ("Use an eyebrow brush to brush the eyebrows out, and blend the eyebrow fill so that it looks natural and not artificial.")
        print ("Please, you do NOT want artificial eyebrows, TRUST me.")
    print (" ")
    print ("Let's move onto eye makeup.")
    print ("There are many factors of the eye to consider at this point, such as: eye shape and eye color.")
    print ("Begin with applying an eye primer all across the eyelid.")
    print ("This will give your eyelid an even tone and texture, providing a smooth, even base for your eye makeup.")
    print ("After applying a primer, you can set the primer with a translucent powder, setting the canvas so it won't move with time.")
    print (" ")
    print ("Now you will choose your colors (please keep in mind your skin tone and undertone complimentary colors).")
    if color == "brown":
        print ("You have stunning, brown eyes.")
        print ("You can use your preferred colors for eye makeup, because your eye color is a nuetral one.")
    if color == "blue":
        print ("You have stunning, blue eyes.")
        print ("You may want to consider the following colors when applying eye makeup:")
        print ("Golds, bronzes, coppers, pinks, creams, browns.")
        print ("You may want to avoid bright, loud colors. They will detract from the natural beauty of your eyes.")
    if color == "gray":
        print ("You have stunning, gray eyes.")
        print ("The colors that you use will effect the color of your eye.")
        print ("If you use oranges, your eyes will seem blue.")
        print ("If you use pinks, your eyes will seem green.")
        print ("Grays and silvers will bring out the gray.")
        print ("You may want to use shimmers - this will add life and color to your neutral tone.")
    if color == "green":
        print ("You have stunning, green eyes.")
        print ("You may want to consider the following colors when applying eye makeup:")
        print ("wine, burgundy, taupe, grays, black, golds, and purples.")
        print ("You may want to avoid silvers and blues. They will detract from the natural beauty of your eyes.")
    if color == "hazel":
        print ("You have stunning, hazel eyes.")
        print ("You may want to consider the following colors when applying eye makeup:")
        print ("Greens, browns, golds, pinks, rose golds, creams, muaves.")
        print ("You may want to avoid blues. They will detract from the natural beauty of your eyes.")
    print ("Now that you have chosen your colors, you are almost ready to apply eye makeup.")
    print (" ")
    print ("First we need to consider your eye shape.")
    print ("As I am sure you have heard, makeup can do magic.")
    print ("By understanding how to properly use makeup, and understanding your personal eye shape, you can adjust your eyes to look the way you want them to.")
    print ("By following this step by step process, you can adjust your eyes to look like what you want them to look like.")
    print (" ")
    if eye == "far set":
        print ("Your eyes are far set.")
        print ("- To give the illusion that your eyes are closer together, widen the distance between the brows, and extend the brow out.")
        print ("- Use a darker color of eyeshadow along the crease. Concentrate this darker color in the inner corners of the eye.")
        print ("- Use a lighter color from the middle to the outer lid.")
        print ("- When applying mascara, focus on the inner corner of the eye.")
    if eye == "close set":
        print ("Your eyes are close set.")
        print ("- To give the illusion that your eyes are farther apart, focus a darker shade of eyeshadow at the outer corners of your eye from the lashline to the crease.")
        print ("- Then put a lighter, reflective shadow on the inner 3/4 of the lid.")
        print ("- Lining your inner rims with a pencil will also help you acheive the look of far set eyes.")
        print ("- Concentrate your mascara on the outer edges of the eye.")
    if eye == "prominent":
        print ("You have prominent eyes.")
        print ("- It is best for you to use medium - dark colors over your lid, give your eye a flatter look.")
        print ("- Blend the shadow up all the way to your eyebrow.")
    if eye == "hooded":
        print ("You have hooded eyes.")
        print ("- To pull back the skin that falls over your lid, shape your brows in this way:")
        print ("- Keep the top of your brow level, and arch the bottom of your brow. Extend your brow out in a nice curve.")
        print ("- Because hooded eyes increase your chance of creasing, be sure to set your eyehadow primer with a translucent powder well.")
        print ("- Create a fake higher crease, by applying a dark shade just above your crease.")
        print ("- Pull the darker color in to the center of the eye, in a straight motion. Be sure to avoid the inner corner.")
        print ("- Blend out in an UPWARD motion.")
        print ("- Be sure to use light colors towards the inner corners and dark colors toward the outer corners.")
        print ("- As you line the lower lashline, be sure to keep the darker shades at the outer corner.")
        print ("- When highlighting the brow bone, apply the highlighter in a thin line right underneath the arch.")
        print ("- Highlight the inner corner and apply a light shimmer over the center of the eye (if you would like).")
        print ("- For eyeliner, apply a thin dark line on the upper lashline and a light color on the lower lashline.")
        print ("Annnnd you are done with the eyes!")
    if eye == "monolid":
        print ("You have monolid eyes.")
        print ("- Start with applying a light, nuetral color over the lid.")
        print ("- Your main work will be with eyeliner.")
        print ("- On the upper lashline, lay the eyeliner on thick, and extend it out in a wing. Blend it with a brush.")
        print ("- Then line the lower lashline with a nude liner to open up the eye.")
        print ("- Arch the eyebrows to add depth to the eye.")
    if eye == "round":
        print ("You have round eyes.")
        print ("- Begin by applying a light, neutral color for a base, and a darker color in the crease.")
        print ("- Then, line the waterlines with eyeliner and apply mascara on the upper lashes.")
    if eye == "upturned":
        print ("You have upturned eyes.")
        print ("- To enhance the beauty of your eyeshape, keep your lid clean with a simple unicolor eyeshadow.")
        print ("- Lightly line the lashlines with eyeliner and extend the liner into a wing.")
    if eye == "downturned":
        print ("You have downturned eyes.")
        print ("- Begin by applying a nuetral colored eyeshadow all across the lid.")
        print ("- Add a darker color in the crease, and apply eyeliner and extend it out and up to help lift the eye.")
    if eye == "almond":
        print ("You have almond eyes.")
        print ("- Begin by applying a light color all across the lid and blend a darker color into the crease.")
        print ("- Almond eyes look best with a smokey look, so extend the dark color out.")
        print ("- Apply eyeliner on the upper and lowe lashline, keeping it thick on the lower lashline.")
        print ("- Add mascara and you are done with the eyes.")

def foundation(skin_type):
    print (" ")
    print ("Now that we have finished with the eyes, let's move onto the face.")
    print ("We will begin with foundation. Some people prefer to start with concealer, that is fine. I prefer to start with foundation.")
    print ("Depending on the look you are going for, you might want to use a lighter or heavier foundation.")
    print ("For the most natural look, stick to a lighter coverage foundation.")
    print ("When buying foundation, ask a proffesional to match the foundation to your skin tone and undertone.")
    print ("When applying foundation, use a beauty blender or a brush to blend it out. ")
    print ("It is best to apply less and build up from there.")
    print ("Blend and blend to create an airbrushed finish.")
    print (" ")
    if skin_type == "dry":
        print ("Because your skin is dry, you are best off using a cream or liquid foundation.")
        print ("Avoid powders, for dry skin, powder leads to cakiness.")
        print ("For all of your skin products stick to liquids and creams.")
    if skin_type == "oily":
        print ("Because your skin is oily, you are best off using powder foundation.")
        print ("After applying foundation, set your skin with a translucent setting powder. This ensures that the makeup won't move with time.")
    if skin_type == "combination":
        print ("Because your skin is a combination of oily and dry, you are best off using a liquid or cream eyeshadow, and then setting the oily parts of your face with a translucent setting powder.")
    print (" ")
    print ("Now that you are finished with foundation, it is time for concealer.")
    print ("Apply concealer over any blemishes on the skin, under the eyes and in the center of the forehead in a fan shape.")
    print ("When applying concealer, apply it lightly and blend it in well to create a natural look!")
    
def bronzer(face_shape):
    print (" ")
    print ("Let's  move onto bronzer.")
    print ("The purpose of bronzer is to add depth and color to the face. Where you will apply bronzer varies according to face shape.")
    print ("Use a warm color that is a few shades darker than your skin.")
    print ("One key to keep in mind is BLEND, BLEND, BLEND!")
    if face_shape == "oval":
        print ("You have an oval shaped face.")
        print ("- It is best for you to apply bronzer at the edges of the forehead and across the forehead.")
        print ("- Add a little across your nose, on your cheekbones and your chin.")
        print ("- Be sure to blend the bronzer in well with a fluffy brush in circular motions. You do not want to end up with streaks all over your face.")
        print ("- That is definitely not natural!")
        print ("Oh wait, one more thing, did I mention - BLEND?!")
    if face_shape == "long":
        print ("You have a long face.")
        print ("- It is best for you to apply bronzer at the edges of the forehead and across the forehead.")
        print ("- Add a little across your nose, and under your cheekbones.")
        print ("- Pull the bronzer from under your cheekbones out and up into the temples.")
        print ("- Then apply bronzer on the chin and pull it upward.")
        print ("- Be sure to blend the bronzer in well with a fluffy brush in circular motions. You do not want to end up with streaks all over your face.")
        print ("- That is definitely not natural!")
        print ("Oh wait, one more thing, did I mention - BLEND?!")
    if face_shape == "heart":
        print ("You have a heart shaped face.")
        print ("- It is best for you to apply bronzer in the hairline and under the cheekbones.")
        print ("- Be sure when applying bronzer under the cheekbones, not to go too deep into the center of the face.")
        print ("- Pull it outward and up.")
        print ("- Be sure to blend the bronzer in well with a fluffy brush in circular motions. You do not want to end up with streaks all over your face.")
        print ("- That is definitely not natural!")
        print ("Oh wait, one more thing, did I mention - BLEND?!")
    if face_shape == "diamond":
        print ("- You have a diamond face shape.")
        print ("- You will begin by applying bronzer in the hairline, focusing on the center of the forehead.")
        print ("- Then apply bronzer on the cheekbones and under the checkbones, pulling it out and up the the forehead.")
        print ("- Next apply bronzer on the chin, blending it down into the jawline.")
        print ("- Finally add a bit of bronzer to the nose.")
        print ("- Be sure to blend the bronzer in well with a fluffy brush in circular motions. You do not want to end up with streaks all over your face.")
        print ("- That is definitely not natural!")
        print ("Oh wait, one more thing, did I mention - BLEND?!")
    if face_shape == "square":
        print ("You have a square shaped face.")
        print ("- It is best for you to apply bronzer under the cheekbones, pulling it upward and out, at the edges of the forehead, and over the nose and chin.")
        print ("- Fun fact: Arched eyebrows can help give the illusion of a more narrow face.")
        print ("- Be sure to blend the bronzer in well with a fluffy brush in circular motions. You do not want to end up with streaks all over your face.")
        print ("- That is definitely not natural!")
        print ("Oh wait, one more thing, did I mention - BLEND?!")
    if face_shape == "round":
        print ("You have a round shaped face.")
        print ("- It is best for you to apply bronzer over the entire outer perimeter of the face.")
        print ("- Add some bronzer on the cheekbones and blend it out.")
        print ("- Using the excess makeup on your brush, blend the bronzer from on the cheekbones down and in towards the center of the face.")
        print ("- Fun fact: Arched eyebrows can help give the illusion of a more narrow face.")
        print ("- Be sure to blend the bronzer in well with a fluffy brush in circular motions. You do not want to end up with streaks all over your face.")
        print ("- That is definitely not natural!")
        print ("Oh wait, one more thing, did I mention - BLEND?!")

def contour(nose_shape, chin_and_jaw_shape):
    print (" ")
    print ("Let's move onto contour.")
    print ("Contour is critical when it comes to corrective makeup.")
    print ("It is what allows you to create structure to the face, and shape to your features.")
    print ("Contour is generally a cool shade a few tones darker that your skin tone. It is matte, not shimmery.")
    print ("Begin by applying contour under the cheekbones, in an angle from the tip of the ear to the mouth.")
    print ("Pull the contour up and out, and be sure not to bring the brush into the center of the face, past the outer end of the eye.")
    print ("Apply contor at the edges of the forehead and blend.")
    if nose_shape == "long":
        print ("To shorten your nose, apply contour under the nose and over the tip of the nose. Be sure to blend it well.")
        print ("Then draw to straight lines at the sides of the nose and blend them in.")
        print ("Highlight the center of the nose.")
    if nose_shape == "short":
        print ("To lengthen the nose, apply highlighter under the nose and over the tip of the nose.")
        print ("Then draw to straight lines at the sides of the nose and blend them in.")
    if nose_shape == "wide":
        print ("To give the illusion of a narrow nose, draw two straight lines from the beginning of your nose to the tip of your nose, keeping them close to each other.")
        print ("Highlight the center of the nose.")
    if nose_shape == "narrow":
        print ("To give the illusion of a wider nose, highlight along the two sides of the nose, in a straight line.")
        print ("Blend it well.")
    if nose_shape == "hooknose":
        print ("To hide the bump on your nose, draw two straight lines down the sides of the nose.")
        print ("Then apply the contour directly onto the raised area.")
        print ("Highlight the tip of the nose and pull it up, but be sure not to highlight the bump. Keep that area dark.")
    if chin_and_jaw_shape == "wide_jaw":
        print ("To make your jaw more narrowed, apply contour right on the jawline, at the edges of the jawline, and under the cheekbones.")
        print ("Be sure to blend it well.")
    if chin_and_jaw_shape == "narrow":
        print ("Use a non-shimmery highlighter at the edges of the jawline and cheekbones to give your jaw a wider look.")
        print ("Be sure to blend it well.")
    if chin_and_jaw_shape == "receding chin":
        print ("Apply a highlighter over the chin and blend well.")
    if chin_and_jaw_shape == "advancing chin":
        print ("Apply contour over the most advanced part of the chin and blend it well.")
        print ("Highlight the lowest point of the chin.")
    if chin_and_jaw_shape == "no jaw":
        print ("To create a jawline, apply contour right underneath the jawline in a straight motion. Bring the contour up to the sides, behind the face.")
        print ("Blend, blend, blend.")
        
def blush_and_highlight(face_shape):
    print (" ")
    print ("Now we will move onto highlighter.")
    print ("I like to apply highlighter before blush, because highlighter tends to be streaky and unnatural, so applying blush after will help blend it in.")
    print ("Because highlighter is difficult to blend (your whole face can become highlighted), I would suggest applying a small amount of highlighter and building it up if necessary.")
    if face_shape == "oval":
        print ("For your oval face shape, it is best to apply highlighter on the high points of the cheeks, underneath the brow bone, the cupid's bow, the chin and the bridge of the nose.")
        print ("Then apply blush on the apples of the cheeks and pull it up into the temples. Sweep it across the nose and blend.")
    if face_shape == "square":
        print ("Your face would do well with highlighter in a \"C\" shape across the cheeks and up into the temples.")
        print ("You can then apply blush to the cheeks and across the nose.")
    if face_shape == "round":
        print ("Your face shape would look awesome with highlighter applied to the bridge of the nose, the center of the forehead, the cupid's bow, the high points of the cheekbones, underneath the brow bone and on the chin.")
        print ("You can then apply blush two fingers away from the nose and pull it out to the cheekbones and up into the temples.")
        print ("Blend it in a vertical manner to prevent streaks.")
    if face_shape == "heart":
        print ("Your face shape would look awesome with highlighter applied to the bridge of the nose, the center of the forehead, the cupid's bow, the high points of the cheekbones, underneath the brow bone and on the chin and jawline.")
        print ("You can then apply blush two fingers away from the nose and pull it out to the cheekbones and up into the temples.")
        print ("Blend it in a vertical manner to prevent streaks.")
    if face_shape == "long":
        print ("To avoid lengthening your face, do not apply highlighter to the forehead or chin.")
        print ("You can apply highlighter on the cheekbones and blend up into the temples, on the browbone, the tip of the nose, and cupi's bow.")
        print ("You can then apply blush to the apples of the cheeks and blend out to avoid streakiness.")
    if face_shape == "diamond":
        print ("Apply highlighter to the high points of the cheeks, the cupid's bow, the brow bone, the jawline and temples.")
        print ("You can then add blush to the apples of the cheeks and blend.")
        
def lips():
    print (" ")
    print ("Finally we will finish with the lips.")
    print ("Line the lips with a lip liner - be sure to stick with the colors in your color family.")
    print ("Fill the lips with lipstick and top with a lip gloss if you like.")
    print ("Set your makeup with a setting spray and you are finished!")
    print (" ")
    print (" ")


print ("Welcome to your custom makeup test!")
print ("In this program, I will ask you for information about your face, and give you advice based on your input. Please note that when it comes to makeup, there are no rules. No two faces are the same, which makes makeup case sensitive. These are general tricks you can use, but be creative and experiment with it! Enjoy!")
print ("If at any point you are unsure about your face information, there are many tests online that you can take to verify your face information.")
print ("One more note, this is advice for your NATURAL makeup look.")
print ("Let's get started!")
num_faces = int(input("How many faces would you like advice for? "))
for i in range(num_faces):
    print ("The first step is to prep your skin with a moisterizer. This will ensure that your makeup doesn't get cakey.")
    # if skin_type == "oily":
    #     print ("You can skip this step. But, in general, you should moisterize. Very often skin is oily due to lack of moisture.")
    face_info = get_face_info()
    color_family(face_info[0], face_info[1])
    eye_makeup(face_info[5], face_info[6], face_info[3])
    foundation(face_info[2])
    bronzer(face_info[3])
    contour(face_info[7], face_info[8])
    blush_and_highlight(face_info[3])
    lips()


print ("This information is based off the comments of the following makeup experts: Alison, Burton, Brolley, Pak, Nikia Joy, Brianna Fox, Chelsea Simmons, Tim Quinn, Metrus and more")